﻿using FinalProject_ConferenceRoomBooking.Data;
using FinalProject_ConferenceRoomBooking.Data_Layer.Entities;
using FinalProject_ConferenceRoomBooking.Services;
using FinalProject_ConferenceRoomBooking.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace FinalProject_ConferenceRoomBooking.Services
{
    public class BookingService : IBookingService
    {
        private readonly ApplicationDbContext _context;

        public BookingService(ApplicationDbContext context)
        {
            _context = context;
        }

        public void CreateBooking(Bookings newBooking)
        {
            ValidateBooking(newBooking);

            // Perform any additional logic before creating the booking

            newBooking.GenerateBookingCode("C001");  // Generate booking code

            _context.Bookings.Add(newBooking);
            _context.SaveChanges();
        }

        public void CreateReservationHolder(ReservationHolder reservationHolder)
        {
            throw new NotImplementedException();
        }

        public void DeleteBooking(int id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Bookings> GetAllBookings()
        {
            throw new NotImplementedException();
        }

        public Bookings GetBookingByDate(DateTime selectDate)
        {
            throw new NotImplementedException();
        }

        public Bookings GetBookingById(int id)
        {
            throw new NotImplementedException();
        }

        public Bookings GetBookingByStatus(string status)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Bookings> GetBookingsByStatus(string status)
        {
            throw new NotImplementedException();
            _context.Bookings.Where(b => b.Status == status).ToList();
        }


        public ReservationHolder GetReservationHolderById(int id)
        {
            throw new NotImplementedException();
        }

        public void UpdateBooking(Bookings updatedBooking)
        {
            throw new NotImplementedException();
        }

        public void UpdateReservationHolder(ReservationHolder updatedReservationHolder)
        {
            throw new NotImplementedException();
        }

        private void ValidateBooking(Bookings newBooking)
        {
            // Check if the number of people attending exceeds the maximum capacity
            var room = _context.ConferenceRooms.Find(newBooking.RoomId);
            if (room != null && newBooking.NumberOfPeople > room.MaximumCapacity)
            {
                throw new InvalidOperationException("Number of people exceeds maximum capacity.");
            }

            // Check if the start date is in the past
            if (newBooking.StartDate < DateTime.Now)
            {
                throw new InvalidOperationException("Booking start date cannot be in the past.");
            }

            // Check if the end date is before the start date
            if (newBooking.EndDate <= newBooking.StartDate)
            {
                throw new InvalidOperationException("Booking end date must be after the start date.");
            }

             ReservationHolder GetReservationHolderById(int id)
            {
                // Implementation to get a reservation holder by ID from the database
                return _context.ReservationHolders.Find(id);
            }

             void CreateReservationHolder(ReservationHolder reservationHolder)
            {
                // Implementation to create a new reservation holder in the database
                _context.ReservationHolders.Add(reservationHolder);
                _context.SaveChanges();
            }

             void UpdateReservationHolder(ReservationHolder updatedReservationHolder)
            {
                // Implementation to update a reservation holder in the database
                _context.Entry(updatedReservationHolder).State = EntityState.Modified;
                _context.SaveChanges();
            }
        }
    }
}