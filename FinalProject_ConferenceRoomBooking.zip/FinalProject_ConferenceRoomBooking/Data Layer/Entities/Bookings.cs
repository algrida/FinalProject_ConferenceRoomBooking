﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace FinalProject_ConferenceRoomBooking.Data_Layer.Entities
{
    public class Bookings
    {
        [Key]
        public string Code { get; set; }
        public bool IsConfirmed { get; set; }
        public bool isDeleted { get; set; }
        public string ConferenceRoomCode { get; set; }
        public int Id { get; set; }

        [Required(ErrorMessage = "Start Date is required.")]
        public DateTime StartDate { get; set; }

        [Required(ErrorMessage = "End Date is required.")]
        public DateTime EndDate { get; set; }

        [Required(ErrorMessage = "Room ID is required.")]
        public int RoomId { get; set; }

        [Required(ErrorMessage = "Number of People is required.")]
        [Range(1, int.MaxValue, ErrorMessage = "Number of People must be greater than 0.")]
        public int NumberOfPeople { get; set; }
        public string Status { get; internal set; }

        public void GenerateBookingCode()
        {
            DateTime currentDate = DateTime.Now;
            string datePart = currentDate.ToString("yyyyMMdd");
            string startTimePart = StartDate.ToString("HHmm");
            string endTimePart = EndDate.ToString("HHmm");

            Code = $"{datePart}-{startTimePart}-{endTimePart}-{ConferenceRoomCode}";
        }

        public ReservationHolder ReservationHolder { get; set; }

        internal void GenerateBookingCode(string v)
        {
            throw new NotImplementedException();
        }
    }
}